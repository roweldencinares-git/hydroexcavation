<?php
/**
 * BeachHydrovac Child Theme Functions
 *
 * @package BeachHydrovac
 * @since 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue parent and child theme styles
 */
function beachhydrovac_enqueue_styles() {
    // Enqueue parent theme stylesheet
    wp_enqueue_style(
        'twentytwentyfive-style',
        get_template_directory_uri() . '/style.css',
        array(),
        wp_get_theme()->parent()->get('Version')
    );

    // Enqueue child theme stylesheet
    wp_enqueue_style(
        'beachhydrovac-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'twentytwentyfive-style' ),
        wp_get_theme()->get('Version')
    );

    // Load Google Fonts - Inter, Montserrat, Roboto
    wp_enqueue_style(
        'beachhydrovac-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&family=Montserrat:wght@600;700&family=Roboto:wght@400;500&display=swap',
        array(),
        null
    );
}
add_action( 'wp_enqueue_scripts', 'beachhydrovac_enqueue_styles' );

/**
 * Register custom color palette for Gutenberg
 */
function beachhydrovac_custom_colors() {
    add_theme_support( 'editor-color-palette', array(
        array(
            'name'  => __( 'Deep Atlantic', 'beachhydrovac-child' ),
            'slug'  => 'deep-atlantic',
            'color' => '#00416A',
        ),
        array(
            'name'  => __( 'Safety Cyan', 'beachhydrovac-child' ),
            'slug'  => 'safety-cyan',
            'color' => '#27AEFD',
        ),
        array(
            'name'  => __( 'Warm Shoreline', 'beachhydrovac-child' ),
            'slug'  => 'warm-shoreline',
            'color' => '#D4A373',
        ),
        array(
            'name'  => __( 'White', 'beachhydrovac-child' ),
            'slug'  => 'white',
            'color' => '#FFFFFF',
        ),
        array(
            'name'  => __( 'Gray 50', 'beachhydrovac-child' ),
            'slug'  => 'gray-50',
            'color' => '#F9FAFB',
        ),
        array(
            'name'  => __( 'Gray 900', 'beachhydrovac-child' ),
            'slug'  => 'gray-900',
            'color' => '#111827',
        ),
    ) );
}
add_action( 'after_setup_theme', 'beachhydrovac_custom_colors' );

/**
 * Add custom font sizes
 */
function beachhydrovac_custom_font_sizes() {
    add_theme_support( 'editor-font-sizes', array(
        array(
            'name' => __( 'Small', 'beachhydrovac-child' ),
            'size' => 14,
            'slug' => 'small'
        ),
        array(
            'name' => __( 'Normal', 'beachhydrovac-child' ),
            'size' => 16,
            'slug' => 'normal'
        ),
        array(
            'name' => __( 'Medium', 'beachhydrovac-child' ),
            'size' => 20,
            'slug' => 'medium'
        ),
        array(
            'name' => __( 'Large', 'beachhydrovac-child' ),
            'size' => 28,
            'slug' => 'large'
        ),
        array(
            'name' => __( 'Huge', 'beachhydrovac-child' ),
            'size' => 36,
            'slug' => 'huge'
        )
    ) );
}
add_action( 'after_setup_theme', 'beachhydrovac_custom_font_sizes' );

/**
 * Register custom widget areas
 */
function beachhydrovac_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area', 'beachhydrovac-child' ),
        'id'            => 'footer-widget-area',
        'description'   => __( 'Appears in the footer section', 'beachhydrovac-child' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'beachhydrovac_widgets_init' );

/**
 * Modify excerpt length
 */
function beachhydrovac_excerpt_length( $length ) {
    return 30;
}
add_filter( 'excerpt_length', 'beachhydrovac_excerpt_length', 999 );

/**
 * Modify excerpt more string
 */
function beachhydrovac_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'beachhydrovac_excerpt_more' );

/**
 * Add custom body classes
 */
function beachhydrovac_body_classes( $classes ) {
    $classes[] = 'beachhydrovac-theme';
    return $classes;
}
add_filter( 'body_class', 'beachhydrovac_body_classes' );

/**
 * Enable support for responsive embeds
 */
function beachhydrovac_theme_support() {
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'wp-block-styles' );
}
add_action( 'after_setup_theme', 'beachhydrovac_theme_support' );

/**
 * Remove WordPress version from head
 */
remove_action('wp_head', 'wp_generator');

/**
 * Add phone number and email to customizer
 */
function beachhydrovac_customize_register( $wp_customize ) {
    // Contact Information Section
    $wp_customize->add_section( 'beachhydrovac_contact_info', array(
        'title'    => __( 'Contact Information', 'beachhydrovac-child' ),
        'priority' => 30,
    ) );

    // Phone Number
    $wp_customize->add_setting( 'beachhydrovac_phone', array(
        'default'           => '757-785-5177',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'beachhydrovac_phone', array(
        'label'    => __( 'Phone Number', 'beachhydrovac-child' ),
        'section'  => 'beachhydrovac_contact_info',
        'type'     => 'text',
    ) );

    // Email Address
    $wp_customize->add_setting( 'beachhydrovac_email', array(
        'default'           => 'info@beachhydrovac.com',
        'sanitize_callback' => 'sanitize_email',
    ) );

    $wp_customize->add_control( 'beachhydrovac_email', array(
        'label'    => __( 'Email Address', 'beachhydrovac-child' ),
        'section'  => 'beachhydrovac_contact_info',
        'type'     => 'email',
    ) );
}
add_action( 'customize_register', 'beachhydrovac_customize_register' );

/**
 * Helper function to get phone number
 */
function beachhydrovac_get_phone() {
    return get_theme_mod( 'beachhydrovac_phone', '757-785-5177' );
}

/**
 * Helper function to get email
 */
function beachhydrovac_get_email() {
    return get_theme_mod( 'beachhydrovac_email', 'info@beachhydrovac.com' );
}

/**
 * Add custom logo support
 */
function beachhydrovac_custom_logo_setup() {
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
}
add_action( 'after_setup_theme', 'beachhydrovac_custom_logo_setup' );
