# BeachHydrovac Child Theme

Custom WordPress child theme for BeachHydrovac built on Twenty Twenty-Five.

## Installation

1. **Upload the theme:**
   - Compress this folder into a .zip file
   - Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
   - Upload the .zip file
   - Click "Install Now"

2. **Activate the theme:**
   - After installation, click "Activate"

## Features

- ✅ Custom BeachHydrovac brand colors (Deep Atlantic, Safety Cyan, Warm Shoreline)
- ✅ Google Fonts integration (Inter, Montserrat, Roboto)
- ✅ Custom Gutenberg color palette
- ✅ Responsive design optimizations
- ✅ SEO-friendly markup
- ✅ Contact information in WordPress Customizer
- ✅ Custom button styles
- ✅ Blog post card styling

## Brand Colors

- **Deep Atlantic:** #00416A (Primary)
- **Safety Cyan:** #27AEFD (Accent)
- **Warm Shoreline:** #D4A373 (Secondary)

## Customization

Go to **Appearance → Customize → Contact Information** to update:
- Phone number (default: 757-785-5177)
- Email address (default: info@beachhydrovac.com)

## Support

For questions or customization requests, contact the BeachHydrovac team.

## Version History

**1.0.0** - Initial release
- Custom brand colors
- Typography system
- Gutenberg integration
- Contact information settings
