<?php
/**
 * Beach Hydrovac Child Theme Functions
 *
 * @package BeachHydrovac
 */

// Enqueue Google Fonts
function beachhydrovac_enqueue_fonts() {
    wp_enqueue_style(
        'beachhydrovac-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@400;500;700&display=swap',
        array(),
        null
    );
}
add_action('wp_enqueue_scripts', 'beachhydrovac_enqueue_fonts');

// Enqueue parent and child theme styles
function beachhydrovac_child_enqueue_styles() {
    // Enqueue parent theme stylesheet
    wp_enqueue_style(
        'kadence-style',
        get_template_directory_uri() . '/style.css',
        array(),
        wp_get_theme('kadence')->get('Version')
    );

    // Enqueue child theme stylesheet
    wp_enqueue_style(
        'beachhydrovac-child-style',
        get_stylesheet_uri(),
        array('kadence-style', 'beachhydrovac-google-fonts'),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'beachhydrovac_child_enqueue_styles');

// Add custom color palette to Gutenberg editor
function beachhydrovac_editor_color_palette() {
    add_theme_support('editor-color-palette', array(
        array(
            'name'  => __('Navy Blue', 'beachhydrovac-child'),
            'slug'  => 'navy-blue',
            'color' => '#1a365d',
        ),
        array(
            'name'  => __('Navy Dark', 'beachhydrovac-child'),
            'slug'  => 'navy-dark',
            'color' => '#0f2442',
        ),
        array(
            'name'  => __('Navy Light', 'beachhydrovac-child'),
            'slug'  => 'navy-light',
            'color' => '#2c5282',
        ),
        array(
            'name'  => __('Yellow', 'beachhydrovac-child'),
            'slug'  => 'yellow',
            'color' => '#f6c915',
        ),
        array(
            'name'  => __('Yellow Dark', 'beachhydrovac-child'),
            'slug'  => 'yellow-dark',
            'color' => '#d4a90a',
        ),
        array(
            'name'  => __('White', 'beachhydrovac-child'),
            'slug'  => 'white',
            'color' => '#ffffff',
        ),
        array(
            'name'  => __('Off White', 'beachhydrovac-child'),
            'slug'  => 'off-white',
            'color' => '#f7fafc',
        ),
        array(
            'name'  => __('Gray', 'beachhydrovac-child'),
            'slug'  => 'gray',
            'color' => '#e2e8f0',
        ),
    ));
}
add_action('after_setup_theme', 'beachhydrovac_editor_color_palette');
